package iitb.CRF;
/**
 *
 * @author Sunita Sarawagi
 *
 */ 


public class Util {
    public static boolean debug=true;
    static public void printDbg(String msg) {
	if (debug) System.out.println(msg);
    }
};


