package iitb.Utils;

/**
 * @author imran
 *
 */
public class ObjectHeap {

    protected int initCapacity = 0;

    public ObjectHeap(int initCapacity) {
        super();
        this.initCapacity = initCapacity;
    }

    public static void main(String[] args) {
    }
}

