/*
 * Created on May 13, 2005
 *
 */
package iitb.AStar;

/**
 * @author imran
 *
 */
public interface BoundUpdate {
    public double getLowerBound(State curState);
}
