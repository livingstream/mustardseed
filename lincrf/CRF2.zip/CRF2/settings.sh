# settings for CRF..
export CLASSPATH=~/Desktop/CRF2/lib/CRF.jar:~/Desktop/CRF2/lib/colt.jar:~/Desktop/CRF2/lib/LBFGS.jar:~/Desktop/CRF2/lib/trove.jar:$CLASSPATH
